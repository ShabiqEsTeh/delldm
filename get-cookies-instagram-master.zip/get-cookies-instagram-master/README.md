# Get Cookies Instagram

## Information
- login.js -> using endpoint for web (not working for some endpoint, include deleting DM)
- login_v2.js -> using endpoint for android

## Requirement
- Node JS 

## Installation

```
$ git clone https://github.com/yaelahan/get-cookies-instagram && cd get-cookies-instagram
$ npm install
```
## Usage
```
$ node {file}.js
```